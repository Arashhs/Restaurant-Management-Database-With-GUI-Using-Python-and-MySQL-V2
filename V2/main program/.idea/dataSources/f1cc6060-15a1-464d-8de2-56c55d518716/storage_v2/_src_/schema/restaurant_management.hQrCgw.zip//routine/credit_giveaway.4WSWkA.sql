create
    definer = root@localhost procedure credit_giveaway(IN amount decimal(10, 2))
BEGIN
            UPDATE customer
            SET customer.credit = customer.credit + amount;
        
        END;

