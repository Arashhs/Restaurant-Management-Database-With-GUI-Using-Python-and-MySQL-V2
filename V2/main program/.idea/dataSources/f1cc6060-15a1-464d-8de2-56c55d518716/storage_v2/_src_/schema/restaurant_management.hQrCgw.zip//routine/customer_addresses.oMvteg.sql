create
    definer = root@localhost function customer_addresses(customer_id int) returns int
BEGIN
            DECLARE num_addresses int;
            set num_addresses = (select count(*) from address where CID = customer_id);
            RETURN num_addresses;
        END;

