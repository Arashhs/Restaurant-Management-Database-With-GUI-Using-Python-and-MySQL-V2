create definer = root@localhost trigger update_ordersLog
    before update
    on orders
    for each row
BEGIN
            INSERT INTO orders_log VALUES(Now(), 'orders', 'update', OLD.orderID, OLD.orderDate, OLD.customerID, OLD.AID, OLD.courierID);
        END;

