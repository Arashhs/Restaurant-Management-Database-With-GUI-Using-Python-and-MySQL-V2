create definer = root@localhost trigger update_customerLog
    before update
    on customer
    for each row
BEGIN
            INSERT INTO customer_log VALUES(Now(), 'customer', 'update', OLD.CID, OLD.FName, OLD.LName, OLD.NID, OLD.cphone, OLD.age, OLD.credit);
        END;

