create definer = root@localhost trigger update_shopOrderLog
    before update
    on shoporder
    for each row
BEGIN
            INSERT INTO shopOrder_log VALUES(Now(), 'shopOrder', 'update', OLD.orderID, OLD.SID, OLD.orderDate);
        END;

