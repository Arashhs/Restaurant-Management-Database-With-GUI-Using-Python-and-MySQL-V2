create
    definer = root@localhost procedure add_new_food(IN food_name varchar(50), IN new_price decimal(10, 2),
                                                    IN start_date date, IN end_date date)
BEGIN
            INSERT INTO `Menu` (`foodName`, `price`, `start`, `end`) VALUES
            (food_name, new_price, start_date, end_date);
            
        END;

