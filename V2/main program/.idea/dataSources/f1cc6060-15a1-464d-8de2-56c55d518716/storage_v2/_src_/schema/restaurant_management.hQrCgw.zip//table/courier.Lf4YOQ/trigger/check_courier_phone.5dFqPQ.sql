create definer = root@localhost trigger check_courier_phone
    before insert
    on courier
    for each row
BEGIN
          IF ((length(NEW.cphone) <> 10) OR not(CAST(NEW.cphone AS CHAR(10)) like '9%')) THEN -- Abort when trying to insert this record
                CALL phone_number_not_valid; -- raise an error to prevent insertion to the table
          END IF;
        END;

