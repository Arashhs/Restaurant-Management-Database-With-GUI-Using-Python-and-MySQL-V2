create definer = root@localhost trigger update_addressLog
    before update
    on address
    for each row
BEGIN
            INSERT INTO address_log VALUES(Now(), 'address', 'update', OLD.AID, OLD.CID, OLD.name, OLD.address, OLD.fphone);
        END;

