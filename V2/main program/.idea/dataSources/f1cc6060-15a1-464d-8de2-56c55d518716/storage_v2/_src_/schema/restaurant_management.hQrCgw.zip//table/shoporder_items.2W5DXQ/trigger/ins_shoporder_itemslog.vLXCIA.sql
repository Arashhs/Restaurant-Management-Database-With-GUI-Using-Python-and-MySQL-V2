create definer = root@localhost trigger ins_shoporder_itemsLog
    after insert
    on shoporder_items
    for each row
BEGIN
            INSERT INTO shoporder_items_log VALUES(Now(), 'shoporder_items', 'insert', NEW.orderID, NEW.SID, NEW.IID, NEW.Iprice, NEW.unit);
        END;

