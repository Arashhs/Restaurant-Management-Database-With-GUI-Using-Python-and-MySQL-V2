create definer = root@localhost trigger update_shopItemLog
    before update
    on shopitem
    for each row
BEGIN
            INSERT INTO shopItem_log VALUES(Now(), 'shopItem', 'update', OLD.SID, OLD.IID, OLD.IName, OLD.Iprice, OLD.start, OLD.end);
        END;

