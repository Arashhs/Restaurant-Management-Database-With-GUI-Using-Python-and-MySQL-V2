create
    definer = root@localhost procedure transfer_money(IN senderID int, IN receiverID int, IN amount int)
BEGIN
            IF (select credit from customer where CID = senderID) >= amount THEN
            update customer
            set credit = credit - amount
            where CID = senderID;
        
            update customer
            set credit = credit + amount
            where CID = receiverID;
        
            END IF;
        END;

