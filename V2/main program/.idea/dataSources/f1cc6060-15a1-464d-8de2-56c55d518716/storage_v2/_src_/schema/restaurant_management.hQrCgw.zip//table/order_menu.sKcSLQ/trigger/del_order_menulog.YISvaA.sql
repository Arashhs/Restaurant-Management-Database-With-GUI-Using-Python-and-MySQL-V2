create definer = root@localhost trigger del_order_menuLog
    before delete
    on order_menu
    for each row
BEGIN
            INSERT INTO order_menu_log VALUES(Now(), 'order_menu', 'delete', OLD.orderID, OLD.foodName, OLD.price, OLD.unit);
        END;

