create definer = root@localhost trigger ins_shopLog
    after insert
    on shop
    for each row
BEGIN
            INSERT INTO shop_log VALUES(Now(), 'shop', 'insert', NEW.SID, NEW.SName, NEW.status);
        END;

