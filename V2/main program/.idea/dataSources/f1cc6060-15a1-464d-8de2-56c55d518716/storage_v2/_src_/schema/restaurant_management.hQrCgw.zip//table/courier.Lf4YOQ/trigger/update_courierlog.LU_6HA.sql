create definer = root@localhost trigger update_courierLog
    before update
    on courier
    for each row
BEGIN
            INSERT INTO courier_log VALUES(Now(), 'courier', 'update', OLD.CNID, OLD.CID, OLD.CFName, OLD.CLName, OLD.cphone);
        END;

