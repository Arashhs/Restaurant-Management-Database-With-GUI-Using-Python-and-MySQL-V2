create
    definer = root@localhost function total_menu_price() returns decimal(10, 2)
BEGIN
            DECLARE total_price decimal(10, 2);
            set total_price= (select sum(price) from menu);
            RETURN total_price;
        END;

