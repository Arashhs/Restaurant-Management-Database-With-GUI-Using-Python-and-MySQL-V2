create definer = root@localhost trigger del_addressLog
    before delete
    on address
    for each row
BEGIN
            INSERT INTO address_log VALUES(Now(), 'address', 'delete', OLD.AID, OLD.CID, OLD.name, OLD.address, OLD.fphone);
        END;

