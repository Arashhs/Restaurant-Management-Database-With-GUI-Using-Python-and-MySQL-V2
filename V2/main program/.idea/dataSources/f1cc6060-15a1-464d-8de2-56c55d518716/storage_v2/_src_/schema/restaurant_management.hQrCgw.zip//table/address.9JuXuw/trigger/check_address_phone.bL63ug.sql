create definer = root@localhost trigger check_address_phone
    before insert
    on address
    for each row
BEGIN
          IF (length(NEW.fphone) <> 10) THEN -- Abort when trying to insert this record
                CALL phone_number_not_valid; -- raise an error to prevent insertion to the table
          END IF;
        END;

