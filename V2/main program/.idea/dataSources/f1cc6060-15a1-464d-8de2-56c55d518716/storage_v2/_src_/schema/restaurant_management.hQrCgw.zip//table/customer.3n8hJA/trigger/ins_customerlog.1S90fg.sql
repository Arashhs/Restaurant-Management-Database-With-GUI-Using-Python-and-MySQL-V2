create definer = root@localhost trigger ins_customerLog
    after insert
    on customer
    for each row
BEGIN
            INSERT INTO customer_log VALUES(Now(), 'customer', 'insert', NEW.CID, NEW.FName, NEW.LName, NEW.NID, NEW.cphone, NEW.age, NEW.credit);
        END;

