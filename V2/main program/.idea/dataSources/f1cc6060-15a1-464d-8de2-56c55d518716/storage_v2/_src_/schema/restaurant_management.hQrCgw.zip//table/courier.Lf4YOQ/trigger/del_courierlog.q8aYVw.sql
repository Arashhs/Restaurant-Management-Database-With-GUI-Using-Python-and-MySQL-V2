create definer = root@localhost trigger del_courierLog
    before delete
    on courier
    for each row
BEGIN
            INSERT INTO courier_log VALUES(Now(), 'courier', 'delete', OLD.CNID, OLD.CID, OLD.CFName, OLD.CLName, OLD.cphone);
        END;

