create
    definer = root@localhost procedure refresh_logs()
BEGIN
            delete from address_log
                where date (now()) - date (logTime) > 3;
            delete from courier_log
                where date (now()) - date (logTime) > 3;
            delete from customer_log
                where date (now()) - date (logTime) > 3;
            delete from menu_log
                where date (now()) - date (logTime) > 3;
            delete from order_menu_log
                where date (now()) - date (logTime) > 3;
            delete from orders_log
                where date (now()) - date (logTime) > 3;
            delete from shop_log
                where date (now()) - date (logTime) > 3;
            delete from shoporder_items_log
                where date (now()) - date (logTime) > 3;
            delete from shoporder_log
                where date (now()) - date (logTime) > 3;
            delete from shoporder_items_log
                where date (now()) - date (logTime) > 3;
        END;

