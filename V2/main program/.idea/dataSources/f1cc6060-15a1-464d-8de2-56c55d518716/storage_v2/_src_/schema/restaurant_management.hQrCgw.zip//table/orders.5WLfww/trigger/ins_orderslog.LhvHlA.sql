create definer = root@localhost trigger ins_ordersLog
    after insert
    on orders
    for each row
BEGIN
            INSERT INTO orders_log VALUES(Now(), 'orders', 'insert', NEW.orderID, NEW.orderDate, NEW.customerID, NEW.AID, NEW.courierID);
        END;

