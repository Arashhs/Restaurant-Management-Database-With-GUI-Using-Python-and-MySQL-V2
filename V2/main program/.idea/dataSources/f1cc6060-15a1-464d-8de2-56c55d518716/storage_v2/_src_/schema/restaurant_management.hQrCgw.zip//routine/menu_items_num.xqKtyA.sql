create
    definer = root@localhost function menu_items_num() returns int
BEGIN
            DECLARE total_num int;
            set total_num = (select count(*) from menu);
            RETURN total_num;
        END;

