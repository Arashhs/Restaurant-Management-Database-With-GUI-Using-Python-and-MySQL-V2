create definer = root@localhost trigger ins_order_menuLog
    after insert
    on order_menu
    for each row
BEGIN
            INSERT INTO order_menu_log VALUES(Now(), 'order_menu', 'insert', NEW.orderID, NEW.foodName, NEW.price, NEW.unit);
        END;

