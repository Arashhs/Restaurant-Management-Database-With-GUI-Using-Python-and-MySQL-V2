create definer = root@localhost trigger ins_shopItemLog
    after insert
    on shopitem
    for each row
BEGIN
            INSERT INTO shopItem_log VALUES(Now(), 'shopItem', 'insert', NEW.SID, NEW.IID, NEW.IName, NEW.Iprice, NEW.start, NEW.end);
        END;

